/* version.h.in. input file for configure */
#define SCWS_VERSION	"1.2.3"
#define SCWS_BUGREPORT	"http://www.xunsearch.com/scws"

